import DanishResource from './resources/dk.json';
import EnglishResource from './resources/en.json';
import AzerbaijaniResource from './resources/az.json';
import TurkishResource from './resources/tr.json';
import VietnameseResource from './resources/vi.json';
import GermanResource from './resources/de.json';
import LatvianResource from './resources/lv.json';
import PortuguesePortugalResource from './resources/pt-PT.json';
import SpanishResource from './resources/es.json';
import SpanishLatinAmericaResource from './resources/es-419.json';
import IndonesianResource from './resources/id.json';
import FinnishResource from './resources/fi-FI.json';
import FrenchResource from './resources/fr.json'
import RomanianResource from './resources/ro.json';
import BosnianResource from './resources/bs.json';
import CroatianResource from './resources/hr.json';
import SerbianLatinResource from './resources/sr-Latn.json';
import SerbianCyrillicResource from './resources/sr-Cyrl.json';
import KlingonResource from './resources/tlh.json';
import BrazilianPortugueseResource from './resources/pt-BR.json';
import RussianResource from './resources/ru.json';
import LithuanianResource from './resources/lt.json';
import HungarianResource from './resources/hu.json';
import ItalianResource from './resources/it.json';
import UkrainianResource from './resources/uk.json';
import JapaneseResource from './resources/ja.json';
import GreekResource from './resources/el.json';
import TaiwaneseResource from './resources/zh-TW.json';
import SimplifiedChineseResource from './resources/zh-CN.json';
import CzechResource from './resources/cs.json';
import PolishResource from './resources/pl.json';
import ArabicResource from './resources/ar.json';

export default {
    da: {
        translation: DanishResource
    },
    en: {
        translation: EnglishResource
    },
    az: {
        translation: AzerbaijaniResource
    },
    tr: {
        translation: TurkishResource
    },
    vi: {
        translation: VietnameseResource
    },
    de: {
        translation: GermanResource
    },
    lv: {
        translation: LatvianResource
    },
    "pt-PT": {
        translation: PortuguesePortugalResource
    },
    "es-419": {
        translation: SpanishLatinAmericaResource
    },
    es: {
        translation: SpanishResource
    },
    id: {
        translation: IndonesianResource
    },
    "fi-FI": {
        translation: FinnishResource
    },
    fr: {
        translation: FrenchResource
    },
    ro: {
        translation: RomanianResource
    },
    bs: {
        translation: BosnianResource
    },
    hr: {
        translation: CroatianResource
    },
    "sr-Latn": {
        translation: SerbianLatinResource
    },
    sr: {
        translation: SerbianCyrillicResource
    },
    tlh: {
        translation: KlingonResource
    },
    "pt-BR": {
        translation: BrazilianPortugueseResource
    },
    ru: {
        translation: RussianResource
    },
    lt: {
        translation: LithuanianResource
    },
    hu: {
        translation: HungarianResource
    },
    it: {
        translation: ItalianResource
    },
    uk: {
        translation: UkrainianResource
    },
    ja: {
        translation: JapaneseResource
    },
    el: {
        translation: GreekResource
    },
    "zh-TW": {
        translation: TaiwaneseResource
    },
    "zh-CN": {
        translation: SimplifiedChineseResource
    },
    cs: {
        translation: CzechResource
    }, 
    pl: {
        translation: PolishResource
    },
    ar: {
        translation: ArabicResource
    }
};
